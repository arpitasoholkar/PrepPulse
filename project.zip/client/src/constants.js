export const TOPICS = [
  "arrays",
  "strings",
  "linked-list",
  "stacks-queues",
  "hashing",
  "sorting",
  "recursion",
  "trees",
  "graphs",
  "dp"
];

export const MEMORY_TYPES = [
  "strength",
  "weakness",
  "mistake",
  "learning_preference",
  "concept_understood",
  "revision_needed"
];

export const MEMORY_STATUS = [
  "active",
  "superseded",
  "corrected"
];

export const MEMORY_SOURCE = [
  "chat",
  "practice",
  "manual",
  "seed"
];

export const EXPLANATION_STYLES = [
  "theory",
  "simple",
  "example",
  "analogy",
  "visual",
  "dry_run"
];

export const ERROR_TYPES = [
  "off_by_one",
  "wrong_base_case",
  "wrong_loop_condition",
  "logic_error",
  "inefficient",
  "edge_case_missed",
  "syntax_error",
  "none"
];
